app.directive('submitcount', function(){
    return {
        link: function(scope, elm){
			
			
			$(".demo").WanSpinner({minValue: 0, start:1,inputWidth: 400});

			
			
			//$(elm).datepicker("option", "dateFormat");
			
			
			
        }
    }
});

 